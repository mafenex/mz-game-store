const WHATSAPP_NUMBER = "258833255852";
// 👆 Troque pelo seu número.
// Exemplo: 841234567 → 258841234567


/* ================= PRODUTOS ================= */

const products = [

  {
    id: 1,
    name: "Pack FC Mobile",
    cat: "FC Mobile",
    price: 500,
    emoji: "⚽",
    desc: "Pack digital para conteúdo gamer autorizado."
  },

  {
    id: 2,
    name: "Gift Card Gamer",
    cat: "Gift Cards",
    price: 1000,
    emoji: "🎁",
    desc: "Código digital sujeito à região e disponibilidade."
  },

  {
    id: 3,
    name: "Pack Recursos",
    cat: "Recursos",
    price: 750,
    emoji: "🪙",
    desc: "Pacote de recursos digitais para jogos compatíveis."
  },

  {
    id: 4,
    name: "Skin Pack",
    cat: "Digital",
    price: 650,
    emoji: "🧩",
    desc: "Pacote visual para uso onde for permitido."
  },

  {
    id: 5,
    name: "Coins Pack",
    cat: "Recursos",
    price: 1200,
    emoji: "💰",
    desc: "Recurso digital para jogos que permitam a compra."
  },

  {
    id: 6,
    name: "Starter Gamer",
    cat: "Digital",
    price: 900,
    emoji: "🎮",
    desc: "Kit digital para começar sua experiência gamer."
  },

  {
    id: 7,
    name: "FC Mobile Pack Pro",
    cat: "FC Mobile",
    price: 1500,
    emoji: "🏆",
    desc: "Pacote premium de recursos autorizados."
  },

  {
    id: 8,
    name: "Gift Card Digital",
    cat: "Gift Cards",
    price: 2000,
    emoji: "💳",
    desc: "Cartão digital sujeito à região e disponibilidade."
  }

];


/* ================= VARIÁVEIS ================= */

let cart = JSON.parse(
  localStorage.getItem("mz_cart") || "[]"
);

let currentCat = "Todos";


/* ================= ATALHO ================= */

const $ = selector =>
  document.querySelector(selector);


/* ================= FORMATAÇÃO ================= */

function money(value) {

  return value.toLocaleString("pt-MZ") + " MT";

}


/* ==================================================
   WHATSAPP
   ================================================== */

function buyOnWhatsApp(productId) {

  const product = products.find(
    product => product.id === productId
  );

  if (!product) return;


  const message =

`Olá! 👋 Quero comprar este produto na MZ Game Store:

🎮 Produto: ${product.name}

💰 Preço: ${money(product.price)}

Gostaria de saber como posso efetuar o pagamento.`;


  const whatsappURL =
    `https://wa.me/${WHATSAPP_NUMBER}?text=` +
    encodeURIComponent(message);


  window.open(
    whatsappURL,
    "_blank",
    "noopener,noreferrer"
  );

}


/* ================= SALVAR CARRINHO ================= */

function saveCart() {

  localStorage.setItem(
    "mz_cart",
    JSON.stringify(cart)
  );

  renderCart();

  updateCartCount();

}


/* ================= CONTADOR ================= */

function updateCartCount() {

  const count =
    cart.reduce(
      (total, product) =>
        total + product.qty,
      0
    );

  $("#cartCount").textContent = count;

}


/* ================= PRODUTOS ================= */

function renderProducts() {

  const search =
    $("#searchInput")
      .value
      .toLowerCase();


  const filtered =
    products.filter(product => {

      const categoryMatch =
        currentCat === "Todos" ||
        product.cat === currentCat;


      const searchMatch =
        `${product.name} ${product.desc}`
          .toLowerCase()
          .includes(search);


      return categoryMatch && searchMatch;

    });


  $("#productGrid").innerHTML =

    filtered.length

      ?

      filtered.map(product => `

        <article class="product">

          <div class="product-img">
            ${product.emoji}
          </div>


          <div class="product-info">

            <span class="tag">
              ${product.cat.toUpperCase()}
            </span>


            <h3>
              ${product.name}
            </h3>


            <p>
              ${product.desc}
            </p>


            <span class="price">
              ${money(product.price)}
            </span>


            <br>


            <!-- CARRINHO -->

            <button
              class="add"
              onclick="addToCart(${product.id})">

              🛒 Adicionar

            </button>


            <!-- WHATSAPP -->

            <button
              class="whatsapp"
              onclick="buyOnWhatsApp(${product.id})">

              📲 Comprar pelo WhatsApp

            </button>

          </div>

        </article>

      `).join("")

      :

      `
        <p class="muted">
          Nenhum produto encontrado.
        </p>
      `;

}


/* ================= ADICIONAR ================= */

function addToCart(productId) {

  const product =
    products.find(
      product =>
        product.id === productId
    );


  if (!product) return;


  const existing =
    cart.find(
      item =>
        item.id === productId
    );


  if (existing) {

    existing.qty++;

  }

  else {

    cart.push({

      ...product,

      qty: 1

    });

  }


  saveCart();

  showToast(
    "Produto adicionado ao carrinho!"
  );

}


/* ================= ALTERAR QUANTIDADE ================= */

function changeQuantity(
  productId,
  amount
) {

  const item =
    cart.find(
      product =>
        product.id === productId
    );


  if (!item) return;


  item.qty += amount;


  if (item.qty <= 0) {

    cart =
      cart.filter(
        product =>
          product.id !== productId
      );

  }


  saveCart();

}


/* ================= RENDER CARRINHO ================= */

function renderCart() {

  const container =
    $("#cartItems");


  if (!cart.length) {

    container.innerHTML = `

      <p class="muted">
        Seu carrinho está vazio.
      </p>

    `;

    $("#cartTotal").textContent =
      "0 MT";

    return;

  }


  container.innerHTML =

    cart.map(item => `

      <div class="cart-item">

        <div class="emoji">
          ${item.emoji}
        </div>


        <div>

          <h4>
            ${item.name}
          </h4>

          <small>
            ${money(item.price)} cada
          </small>

        </div>


        <div class="qty">

          <button
            onclick="changeQuantity(${item.id}, -1)">

            −

          </button>


          <b>
            ${item.qty}
          </b>


          <button
            onclick="changeQuantity(${item.id}, 1)">

            +

          </button>

        </div>

      </div>

    `).join("");


  const total =
    cart.reduce(
      (sum, item) =>
        sum + item.price * item.qty,
      0
    );


  $("#cartTotal").textContent =
    money(total);

}


/* ================= ABRIR CARRINHO ================= */

function openCart() {

  $("#cartDrawer")
    .classList
    .add("open");


  $("#overlay")
    .classList
    .add("open");

}


/* ================= FECHAR CARRINHO ================= */

function closeCart() {

  $("#cartDrawer")
    .classList
    .remove("open");


  $("#overlay")
    .classList
    .remove("open");

}


/* ================= NOTIFICAÇÃO ================= */

function showToast(message) {

  const toast =
    $("#toast");


  toast.textContent =
    message;


  toast.classList.add("show");


  setTimeout(() => {

    toast.classList.remove("show");

  }, 2000);

}


/* ================= CATEGORIAS ================= */

document
  .querySelectorAll(".category")
  .forEach(button => {

    button.addEventListener(
      "click",
      () => {

        document
          .querySelectorAll(".category")
          .forEach(
            item =>
              item.classList
                .remove("active")
          );


        button.classList
          .add("active");


        currentCat =
          button.dataset.cat;


        renderProducts();

      }
    );

  });


/* ================= PESQUISA ================= */

$("#searchInput")
  .addEventListener(
    "input",
    renderProducts
  );


/* ================= BOTÃO CARRINHO ================= */

$("#cartBtn")
  .addEventListener(
    "click",
    openCart
  );


$("#closeCart")
  .addEventListener(
    "click",
    closeCart
  );


$("#overlay")
  .addEventListener(
    "click",
    closeCart
  );


/* ================= CHECKOUT ================= */

$("#checkoutBtn")
  .addEventListener(
    "click",
    () => {

      if (!cart.length) {

        showToast(
          "Adicione produtos primeiro."
        );

        return;

      }


      $("#checkoutModal")
        .classList
        .add("open");


      closeCart();

    }
  );


/* ================= FECHAR CHECKOUT ================= */

$("#closeModal")
  .addEventListener(
    "click",
    () => {

      $("#checkoutModal")
        .classList
        .remove("open");

    }
  );


/* ================= FORMULÁRIO ================= */

$("#checkoutForm")
  .addEventListener(
    "submit",
    event => {

      event.preventDefault();


      const data =
        Object.fromEntries(
          new FormData(
            event.target
          )
        );


      const total =
        cart.reduce(
          (sum, item) =>
            sum +
            item.price *
            item.qty,
          0
        );


      const order = {

        id:
          "MZ-" +
          Date.now()
            .toString()
            .slice(-6),

        date:
          new Date()
            .toLocaleString(
              "pt-MZ"
            ),

        ...data,

        items: cart,

        total

      };


      const orders =
        JSON.parse(
          localStorage.getItem(
            "mz_orders"
          ) || "[]"
        );


      orders.unshift(order);


      localStorage.setItem(
        "mz_orders",
        JSON.stringify(orders)
      );


      cart = [];


      saveCart();


      event.target.reset();


      $("#checkoutModal")
        .classList
        .remove("open");


      renderOrders();


      showToast(
        "Pedido criado com sucesso!"
      );

    }
  );


/* ================= PEDIDOS ================= */

function renderOrders() {

  const orders =
    JSON.parse(
      localStorage.getItem(
        "mz_orders"
      ) || "[]"
    );


  if (!orders.length) {

    $("#ordersBox").innerHTML =
      "Ainda não existem pedidos neste dispositivo.";

    return;

  }


  $("#ordersBox").innerHTML =

    orders.map(order => `

      <div class="order">

        <strong>
          ${order.id}
        </strong>

        · ${order.date}

        <br>

        <small>

          ${order.name}

          ·

          ${order.payment}

          ·

          Total:

          ${money(order.total)}

        </small>

      </div>

    `).join("");

}


/* ================= PESQUISA ================= */

$("#searchBtn")
  .addEventListener(
    "click",
    () => {

      document
        .querySelector("#products")
        .scrollIntoView();


      $("#searchInput")
        .focus();

    }
  );


/* ================= MENU MOBILE ================= */

$("#menuBtn")
  .addEventListener(
    "click",
    () => {

      $("#nav")
        .classList
        .toggle("open");

    }
  );


/* ================= INICIALIZAÇÃO ================= */

renderProducts();

renderCart();

updateCartCount();

renderOrders();

